#MsTimer2 Library#

Run a function every millisecond.

http://www.pjrc.com/teensy/td_libs_MsTimer2.html

Originally written by Javier Valencia
